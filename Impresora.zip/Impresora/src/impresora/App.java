/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class App {
    private MBinario colaImpresion;
    private HashTable<String, RegistroImpresion> tablaRegistros;
    private LinkedList<Usuario> usuarios;
    private Reloj reloj;
    
    public App() {
        this.colaImpresion = new MBinario();
        this.tablaRegistros = new HashTable(1);
        this.usuarios = new LinkedList<>();
        this.reloj = new Reloj();
    }

    public void abrirArchivo() throws Exception{
        boolean valid = false;
        while(!valid){
            try{
                JFileChooser file=new JFileChooser();
                file.showOpenDialog(null);
                File abre=file.getSelectedFile();
                String aux="";   
                valid = true;
                if(abre!=null){
                    FileReader archivos=new FileReader(abre);
                    BufferedReader lee=new BufferedReader(archivos);
                    while((aux=lee.readLine())!=null){
                        String[] auxSeparado = aux.split(", ");
                        String User = auxSeparado[0];
                        if(!User.equals("usuario")){
                            String TypeS = auxSeparado[1];
                            boolean a = false;
                            Prioridad prioridad = null;

                            if(null == TypeS){
                                prioridad = null;
                            }
                            else switch (TypeS) {
                            case "prioridad_alta":
                                {
                                    prioridad = Prioridad.ALTA;
                                    a = true;
                                        break;
                                }
                            case "prioridad_media":
                                {
                                    prioridad = Prioridad.MEDIA;
                                    break;
                                }
                            case "prioridad_baja":
                                {
                                    prioridad = Prioridad.BAJA;
                                    a = true;
                                    break;
                                }
                            default:
                                {
                                    a = true;
                                    break;
                                }
                            }
                            if(a){
                                Usuario nuevoUsuario = new Usuario(User, prioridad);
                                usuarios.addLast(nuevoUsuario);
                            }
                        }
                    }
                lee.close();
                valid = true;
                }
            }
            catch(IOException ex){
                JOptionPane.showMessageDialog(null, "Error.");
            }
        }
    }

    
    public void agregarUsuario() {
        boolean valid = true;
        boolean valid1 = true;
        while(valid1){
            String identificadorUsuario = JOptionPane.showInputDialog("Ingrese el nombre del usuario:");
            Usuario usuario = buscarUsuario(identificadorUsuario);
            if(usuario != null){
                valid = false;
                valid1 = false;
            }
            if(valid1){
                String tipo = JOptionPane.showInputDialog("Ingrese el numero correspondiente al nivel de prioridad del documento:\n1. Alta.\n2. Media.\n 3. Baja.");
                Prioridad prioridad = null;
                if("1".equals(tipo)){
                    prioridad = Prioridad.ALTA;
                }
                else if("2".equals(tipo)){
                    prioridad = Prioridad.MEDIA;
                }
                else if("3".equals(tipo)){
                    prioridad = Prioridad.BAJA;
                }
                else{
                    valid = false;
                    valid1 = false;
                }
                if(valid){
                    Usuario usuarioDefinitivo = new Usuario(identificadorUsuario, prioridad);
                    usuarios.addLast(usuarioDefinitivo);
                    JOptionPane.showMessageDialog(null, "Usuario agregado exitosamente.");
                    valid1 = false;
                }
            }
        }
        if(!valid){
            JOptionPane.showMessageDialog(null, "Error. Se le devolvera al menu.");
        }
    }

    public void eliminarUsuario() {
        String identificador = JOptionPane.showInputDialog("Ingrese el nombre del usuario a eliminar:");
        boolean valid = false;
        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getIdentificador().equals(identificador)) {
                usuarios.delete(i);
                valid = true;
                break;
            }
        }
        if(!valid){
            JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
        }
        else{
            if (tablaRegistros.get(identificador) != null) {
                tablaRegistros.remove(identificador);
                JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente.");
            } else {
                JOptionPane.showMessageDialog(null, "Usuario eliminado exitosamente. No se encontraron registros para el usuario.");
            }
        }
    }


    public void crearDocumento() {
        boolean valid = true;
        boolean valid1 = true;
        while(valid1){
            String identificadorUsuario = JOptionPane.showInputDialog("Ingrese el nombre del usuario:");
            String nombreDocumento = JOptionPane.showInputDialog("Ingrese el nombre del documento:");
            int tamano = Utiles.askNumberInput("Ingrese el tamaño del documento:");
            String tipo = JOptionPane.showInputDialog("Ingrese el numero correspondiente al nivel de prioridad del documento:\n1. Alta.\n2. Media.\n 3. Baja.");
            Prioridad prioridad = null;
            if("1".equals(tipo)){
                prioridad = Prioridad.ALTA;
            }
            else if("2".equals(tipo)){
                prioridad = Prioridad.MEDIA;
            }
            else if("3".equals(tipo)){
                prioridad = Prioridad.BAJA;
            }
            else{
                valid = false;
                valid1 = false;
            }
            Documento documento = new Documento(nombreDocumento, tamano, prioridad);
            boolean usuarioEncontrado = false;
            for (int i = 0; i < usuarios.size(); i++) {
                Usuario usuario = usuarios.get(i);
                if (usuario.getIdentificador().equals(identificadorUsuario)) {
                    usuario.agregarDocumento(documento);
                    JOptionPane.showMessageDialog(null, "Documento agregado exitosamente.");
                    usuarioEncontrado = true;
                    valid1 = false;
                    break;
                }
            }
            if (!usuarioEncontrado) {
                JOptionPane.showMessageDialog(null, "Usuario no encontrado.");
            }
        }
        if(!valid){
            JOptionPane.showMessageDialog(null, "Error. Se le devolvera al menu.");
        }
    }


    public Usuario buscarUsuario(String identificadorUsuario) {
        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getIdentificador().equals(identificadorUsuario)) {
                return usuarios.get(i);
            }
        }
        return null;
    }
    
    public Documento buscarDocumento(String identificadorUsuario, String nombreDocumento) {
        for (int i = 0; i < usuarios.size(); i++) {
            for (int j = 0; j < usuarios.get(i).getDocumentos().size(); j++) {
                if (usuarios.get(i).getDocumentos().get(j).getNombre().equals(nombreDocumento)) {
                    return usuarios.get(i).getDocumentos().get(j);
                }
        }
    }
    return null;
}

    public void enviarImpresion() {
        boolean valid = true;
        boolean valid1 = true;
        while (valid1){
            String identificadorUsuario = JOptionPane.showInputDialog("Inserte el nombre del usuario del documento:");
            String nombreDocumento = JOptionPane.showInputDialog("Inserte el nombre del documento:");
            Usuario usuario = buscarUsuario(identificadorUsuario);
            if(usuario == null){
                valid = false;
                valid1 = false;
            }
            Documento documento = buscarDocumento(identificadorUsuario, nombreDocumento);
            if(documento == null){
                valid = false;
                valid1 = false;
            }
            if(valid1){
                RegistroImpresion registro = new RegistroImpresion(documento, (int) reloj.getTiempoTranscurrido());

                colaImpresion.insert(registro);
                tablaRegistros.put(identificadorUsuario, registro);
                valid1 = false;
            }
        }
        if(!valid){
            JOptionPane.showMessageDialog(null, "Error. Se le devolvera al menu.");
        }
    }

    public void eliminarDocumentoCola() {
        boolean valid = true;
        boolean valid1 = true;
        while(valid1){
            String identificadorUsuario = JOptionPane.showInputDialog("Inserte el nombre del usuario del documento:");
            String nombreDocumento = JOptionPane.showInputDialog("Inserte el nombre del documento:");
            if(buscarUsuario(identificadorUsuario) == null){
                valid = false;
                valid1 = false;
            }
            if(buscarDocumento(identificadorUsuario, nombreDocumento) == null){
                valid = false;
                valid1 = false;
            }
            RegistroImpresion registro = null; 
            if(valid1){
                for (int i = 0; i < tablaRegistros.get(identificadorUsuario).size(); i++) {
                    if(tablaRegistros.get(identificadorUsuario).get(i).getDocumento().getNombre().equals(nombreDocumento)){
                        registro = tablaRegistros.get(identificadorUsuario).get(i);
                    }
                }
            }
            if(registro == null){
                valid = false;
                valid1 = false;
            }
            if(valid1){
                colaImpresion.remove(registro);
            }
            valid1 = false;
            if(!valid){
                JOptionPane.showMessageDialog(null, "Error. Se le devolvera al menu.");
            }
        }
    }

    public void eliminarDocumento(){
        boolean valid = true;
        boolean valid1 = true;
        while(valid1){
            String identificadorUsuario = JOptionPane.showInputDialog("Inserte el nombre del usuario del documento:");
            String nombreDocumento = JOptionPane.showInputDialog("Inserte el nombre del documento:");
            boolean existe = false;
            for (int i = 0; i < usuarios.size(); i++) {
                if(identificadorUsuario.equals(usuarios.get(i).getIdentificador())){
                    if(usuarios.get(i).getDocumentos().size() != 0){
                        existe = true;
                        break;
                    }
                }
            }
            if(!existe){
                valid = false;
                valid1 = false;
            }
            if(valid1){
                for (int i = 0; i < usuarios.size(); i++) {
                    for (int j = 0; j < usuarios.get(i).getDocumentos().size(); j++) {
                        if (usuarios.get(i).getDocumentos().get(j).getNombre().equals(nombreDocumento)) {
                            usuarios.get(i).getDocumentos().delete(j);

                        }
                    }
                }
            }
            valid1 = false;
        }
        if(!valid){
            JOptionPane.showMessageDialog(null, "Error. Se le devolvera al menu.");
        }
        else{
            JOptionPane.showMessageDialog(null, "Documento de usuario eliminado exitosamente.");
        }
    }
    
    public void liberarImpresora() {
        RegistroImpresion registro = colaImpresion.removeMin();
        JOptionPane.showMessageDialog(null, "Documento liberado.");
    }
    
    //me esta resultando en un arbol mocho y por tiempo no supe como solucionar el error que abre una pagina cada vez que se agrega y elimina un documento del monticulo binario
    public void mostrarMBinario(){ 
        JFrame frame = new JFrame("Monticulo Binario");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        GraficoMBinario grafico = new GraficoMBinario();
        for (int i = 0; i < colaImpresion.getHeap().size(); i++) {
            RegistroImpresion registro = colaImpresion.getHeap().get(i);
            Documento documento = registro.getDocumento();
            grafico.insertar(documento.getNombre(), registro.getEtiquetaTiempo());
        }
        frame.add(grafico);
        frame.setVisible(true);
    }
    
    public void mostrarUsuariosDocumentos(){

        JFrame texto = new JFrame("Usuarios y documentos.");
        texto.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        texto.setSize(300, 200);
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.add(new JLabel("Usuarios y sus documentos:"));
        for (int i = 0; i < usuarios.size(); i++) {
            panel.add(new JLabel("Usuario: " + usuarios.get(i).getIdentificador()));
            panel.add(new JLabel("Documentos:"));
            for (int j = 0; j < usuarios.get(i).getDocumentos().size(); j++) {
                panel.add(new JLabel(usuarios.get(i).getDocumentos().get(j).getNombre()));
            }
        }
        texto.add(panel);
        texto.setVisible(true);
    }
    
}