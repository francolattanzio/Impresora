/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

/**
 *
 * @author user
 * @param <T>
 * @param <H>
 */
public class HashTable<K, V> {
    private class Entry {
        K key;
        LinkedListH<V> values;

        public Entry(K key, V value) {
            this.key = key;
            this.values = new LinkedListH<>();
            this.values.add(value);
        }
    }

    private LinkedListH<Entry>[] entries;
    private int size;
    private int capacity;

    public HashTable(int capacity) {
        this.capacity = capacity;
        this.entries = new LinkedListH[capacity];
        this.size = 0;
    }

    public void put(K key, V value) {
        if (size == capacity)
            resize();

        int index = hash(key);
        if (entries[index] == null)
            entries[index] = new LinkedListH<>();

        LinkedListH<Entry> bucket = entries[index];
        for (int i = 0; i < bucket.size(); i++) {
            Entry entry = bucket.get(i);
            if (entry.key.equals(key)) {
                entry.values.add(value);
                return;
            }
        }

        bucket.add(new Entry(key, value));
        size++;
    }

    public LinkedListH<V> get(K key) {
        int index = hash(key);
        LinkedListH<Entry> bucket = entries[index];
        if (bucket != null) {
            for (int i = 0; i < bucket.size(); i++) {
                Entry entry = bucket.get(i);
                if (entry.key.equals(key))
                    return entry.values;
            }
        }

        return null;
    }

    public void remove(K key) {
        int index = hash(key);
        LinkedListH<Entry> bucket = entries[index];
        if (bucket == null)
            throw new IllegalStateException();

        for (int i = 0; i < bucket.size(); i++) {
            Entry entry = bucket.get(i);
            if (entry.key.equals(key)) {
                bucket.remove(i);
                size--;
                return;
            }
        }

        throw new IllegalStateException();
    }

    private int hash(K key) {
        return Math.abs(key.hashCode()) % capacity;
    }

    private void resize() {
        capacity *= 2;
        LinkedListH<Entry>[] oldEntries = entries;
        entries = new LinkedListH[capacity];
        size = 0;

        for (LinkedListH<Entry> bucket : oldEntries) {
            if (bucket != null) {
                for (int i = 0; i < bucket.size(); i++) {
                    Entry entry = bucket.get(i);
                    for (int j = 0; j < entry.values.size(); j++) {
                        V value = entry.values.get(j);
                        put(entry.key, value);
                    }
                }
            }
        }
    }
}