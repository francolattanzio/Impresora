/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

import Interfaces.Principal;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;
/**
 *
 * @author user
 */
public class Impresora {
    public static void main(String[] args) {
        Principal inicio = new Principal();
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
    }
}