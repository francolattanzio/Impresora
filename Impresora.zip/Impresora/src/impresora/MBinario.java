/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

/**
 *
 * @author user
 */
public class MBinario {
    private LinkedList<RegistroImpresion> heap;

    public MBinario() {
        heap = new LinkedList<>();
    }

    public LinkedList<RegistroImpresion> getHeap() {
        return heap;
    }

    public void setHeap(LinkedList<RegistroImpresion> heap) {
        this.heap = heap;
    }
    
    public void insert(RegistroImpresion registro) {
        switch (registro.getPrioridad()) {
            case ALTA:
                registro.setEtiquetaTiempo(registro.getEtiquetaTiempo() / 3);
                break;
            case MEDIA:
                registro.setEtiquetaTiempo(registro.getEtiquetaTiempo() / 2);
                break;
            case BAJA:
            default:
                break;
        }

        heap.addLast(registro);
        int currentIndex = heap.size() - 1;
        int parentIndex = (currentIndex - 1) / 2;

        while (currentIndex > 0 && 
               heap.get(currentIndex).getPrioridad().ordinal() < 
               heap.get(parentIndex).getPrioridad().ordinal()) {
            swap(heap, currentIndex, parentIndex);
            currentIndex = parentIndex;
            parentIndex = (currentIndex - 1) / 2;
        }
    }

    public RegistroImpresion removeMin() {
        if (heap.isEmpty()) {
            throw new IllegalStateException("Heap is empty");
        } else if (heap.size() == 1) {
            return heap.deleteFirst();
        }

        RegistroImpresion min = heap.get(0);
        heap.addFirst(heap.deleteLast());
        minHeapify(0);
        return min;
    }

    private void minHeapify(int index) {
        int leftChildIndex = 2 * index + 1;
        int rightChildIndex = 2 * index + 2;
        int smallest = index;

        if (leftChildIndex < heap.size() && 
            heap.get(leftChildIndex).getPrioridad().ordinal() < 
            heap.get(smallest).getPrioridad().ordinal()) {
            smallest = leftChildIndex;
        }

        if (rightChildIndex < heap.size() && 
            heap.get(rightChildIndex).getPrioridad().ordinal() < 
            heap.get(smallest).getPrioridad().ordinal()) {
            smallest = rightChildIndex;
        }

        if (smallest != index) {
            swap(heap, index, smallest);
            minHeapify(smallest);
        }
    }

    private void swap(LinkedList<RegistroImpresion> list, int i, int j) {
        RegistroImpresion temp = list.get(i);
        list.set(i, list.get(j));
        list.set(j, temp);
    }
    
    public String printHeap() {
        StringBuilder sb = new StringBuilder();
        Node<RegistroImpresion> current = heap.getHead();
        while (current != null) {
            RegistroImpresion registro = current.getData();
            sb.append(registro.getDocumento().getNombre());
            sb.append(" (");
            sb.append(registro.getPrioridad());
            sb.append(")\n");
            current = current.getNext();
        }
        return sb.toString();
    }
    
    public void remove(RegistroImpresion registro) {
        int index = -1;
        for (int i = 0; i < heap.size(); i++) {
            if (heap.get(i).equals(registro)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            throw new IllegalArgumentException("Registro no encontrado en el montículo");
        }
        registro.setEtiquetaTiempo(Integer.MAX_VALUE);
        while (index > 0) {
            swap(heap, index, (index - 1) / 2);
            index = (index - 1) / 2;
       }
        removeMin();
    }
}