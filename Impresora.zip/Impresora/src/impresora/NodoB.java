/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

/**
 *
 * @author user
 */
public class NodoB {

    private Object element;
    private NodoB leftSon, rightSon;
    private int prioridad;
    
    public NodoB(Object element, int prioridad){
        this.element = element;
        this.leftSon = null;
        this.rightSon = null;
        this.prioridad = prioridad;
    }

    public Object getElement() {
        return element;
    }

    public int getPrioridad() {
        return prioridad;
    }
    
    public NodoB getLeftSon() {
        return leftSon;
    }

    public void setLeftSon(NodoB leftSon) {
        this.leftSon = leftSon;
    }

    public NodoB getRightSon() {
        return rightSon;
    }

    public void setRightSon(NodoB rightSon) {
        this.rightSon = rightSon;
    }
    
    public boolean isLeaf(){
        return getLeftSon() == null && getRightSon() == null;
    }
    
}
