/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

/**
 *
 * @author user
 */
public class RegistroImpresion {
    private Documento documento;
    private int etiquetaTiempo;

    public RegistroImpresion(Documento documento, int etiquetaTiempo) {
        this.documento = documento;
        this.etiquetaTiempo = etiquetaTiempo;
    }

    public Documento getDocumento() {
        return documento;
    }

    public void setDocumento(Documento documento) {
        this.documento = documento;
    }

    public int getEtiquetaTiempo() {
        return etiquetaTiempo;
    }

    public void setEtiquetaTiempo(int etiquetaTiempo) {
        this.etiquetaTiempo = etiquetaTiempo;
    }

    public Prioridad getPrioridad() {
        if (documento.getPrioridad() == Prioridad.ALTA) {
            return Prioridad.ALTA;
        } else if (documento.getPrioridad() == Prioridad.MEDIA) {
            return Prioridad.MEDIA;
        } else {
            return Prioridad.BAJA;
        }
    }
}