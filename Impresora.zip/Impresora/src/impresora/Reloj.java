/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

/**
 *
 * @author user
 */
public class Reloj {
    private long tiempoInicio;

    public Reloj() {
        this.tiempoInicio = System.currentTimeMillis();
    }

    public long getTiempoTranscurrido() {
        return System.currentTimeMillis() - tiempoInicio;
    }

    public void reiniciar() {
        this.tiempoInicio = System.currentTimeMillis();
    }
}