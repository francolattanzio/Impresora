/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;


/**
 *
 * @author user
 */
public class Usuario {
    private String identificador;
    private Prioridad prioridad;
    private LinkedList<Documento> documentos;

    public Usuario(String identificador, Prioridad prioridad) {
        this.identificador = identificador;
        this.prioridad = prioridad;
        this.documentos = new LinkedList<>();
    }

    public String getIdentificador() {
        return this.identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    public Prioridad getPrioridad() {
        return this.prioridad;
    }

    public void setPrioridad(Prioridad prioridad) {
        this.prioridad = prioridad;
    }

    public LinkedList<Documento> getDocumentos() {
        return this.documentos;
    }

    public void setDocumentos(LinkedList<Documento> documentos) {
        this.documentos = documentos;
    }

    public void agregarDocumento(Documento documento) {
        documentos.add(documento);
    }

    public void eliminarDocumento(Documento documento) {
        documentos.remove(documento);
    }
}