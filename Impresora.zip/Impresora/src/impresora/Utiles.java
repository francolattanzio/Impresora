/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impresora;

import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class Utiles {
    
    public static int askNumberInput (String message) {
        
        boolean valid = false;
        String input = "";
        
        while (!valid){
            
            try{
                input = JOptionPane.showInputDialog(message);
                Integer.parseInt(input);
                valid = true;
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Entrada invalida");
            }
        }
        return Integer.parseInt(input);
    }
    
    public static String askStringInput (String message) {
        
        boolean valid = false;
        String input = "";
        
        while(!valid){
            
            input = JOptionPane.showInputDialog(message);
                
            if(input.isBlank() == false){
                
                valid = true;
                
            }
            
            else{
                
                JOptionPane.showMessageDialog(null, "entrada invalidada");
            }
                
        }
        
        return input;
        
    }
}
